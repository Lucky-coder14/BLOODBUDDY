package com.example.bloodbuddy.Email;

public class Util {
    public static  final String EMAIL = "luckykumari1407@gmail.com";
    public static final String PASSWORD = "pyhropmmqundvstg";

}
